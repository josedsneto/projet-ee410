close all; 
clear;

g = 9.81;
L = 0.5;
m = 0.1;
M = 2;
x0 = [2; 5*pi/180; 0 ;0];

A = [0,0,1,0;0,0,0,1;0,(-m*g)/M,0,0;0,(m+M)*g/(M*L),0,0];
B = [0;0;1/M;(-1)/(M*L)];
% BO : deltaXpoint = A*deltaX + B*deltaU

%% 1.3 Propriété de la commande

% si rank(ctrb(A,B)) == n  =>  système complètement commandable
rank(ctrb(A,B)); % >> 4 donc système complètement commandable

%% 1.4 Propriété de l'observabilité

% On souhaite observer théta  =>  y_theta = [0,1,0,0]*x
% si rank(obsv(A,B)) == n  =>  système complètement observable
C_theta = [0,1,0,0];

rank(obsv(A,C_theta)); % >> 2 donc système non complètement observable
null(obsv(A,C_theta)); % retourne les états non observables
% ans =
% 
%     -1     0
%      0     0
%      0    -1
%      0     0


% On souhaite observer E_1  =>  y_theta = [1,0,0,0]*x
C_E = [1,0,0,0];
rank(obsv(A,C_E)); % >> 4 donc système complètement observable
null(obsv(A,C_E)); % retourne les états non observables ici matrice nulle

%% Commande locale PD

% On souhaite observer theta donc
C_theta = [0,1,0,0];

% Récupération de la fonction de transfert via la représentation d'état
[num, den] = ss2tf(A,B,C_theta,0); % D = 0
H_theta = tf(num,den); 

% H théorique
H_theorie = tf(-1, [M*L 0 -(m+M)*g]);

% Comparaison des bodes impossible car on a pas ignoré les termes
% négligeables de H_theta
% close all
% figure ;
% subplot(2,1,1)
% bode(H_theta);
% subplot(2,1,2)
% bode(H_theorie);

% BO : deltaXpoint = A*deltaX + B*deltaU

% Pour avoir une stabilité locale, on utilise le critère de Routh sur la
% boucle fermée K(p)*H_1(p)/(1+K(p)*H_1(p))
% d'après critère de Routh, k1 < -(m+M)*g = 20.6
k1 = -21;
% d'après critère de Routh, k2 < 0
k2 = -1;

K = [0 k1 0 k2];

% BF : deltaXpoint = (A - B*K)*deltaX
eig(A-B*K);
% Valeurs propres => instable
% ans =
% 
%    0.0000 + 0.0000i
%    0.0000 + 0.0000i
%   -0.5000 + 0.3860i
%   -0.5000 - 0.3860i


%% 1.5 Commande par retour d'état complet

x_0 = [1;10*pi/180;0.2;0.3];
% On cherche K tels que eig(A-BK) est stable
% On choisit proche de la bande passante du système en utilisant bode(S);
%                   v   v   v  v
K = place(A,B,1/3*[-5,-5.5,-6,-7]);
% On choisit de manière à ce que la BF coupe à zéro la BO

figure;
initial(A-B*K,zeros(4,1),eye(4),zeros(4,1),x_0);
% On choisit de manière à ce que la BF coupe à zéro la BO 

figure;
hold on;
sigma(A, B, K, 0);
sigma(A, B, C_E, 0);

%% 1.6 Tracer des fonctions de sensibilités

figure;
[Nkab,Dkab]=ss2tf(A,B,K,0);
KAB=tf(Nkab,Dkab); % Transfert de boucle
S=feedback(1,KAB); % Fonction de sensibilité
sigma(KAB,S,{10^-3,10^3});
Gain_S = bode(S);

marge_module = 1/max(Gain_S); 
% ans = 0.6076

% Etablir modèle NL sous Simulink

%% 1.8 Simulation NL avec Régulateur Observateur
% On place le pole pour stabiliser A - LC
L = (lqr(A', C_E', B*B', 10))'; % Donné par le prof