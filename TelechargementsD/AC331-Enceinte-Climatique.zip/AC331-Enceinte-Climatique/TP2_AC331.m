%close all;
%clc; clear;

%% Construction du simulateur

% Fonction de transfert de l'enceinte
He = tf([1], [50, 1]);
[A,B,C,D] = tf2ss([1],[50, 1]);

% Les conditions initiales
CI = (1.16*13 - 5)/C;

%% On est bloqué

[A2,B2,C2,D2] = tf2ss([2.3], [50,1]);

