%% Partie 1
R = 0.4;
L = 0.8;
C = 5;

A = [[0 1/C]; [-1/L -R/L]];
B = [0; 1/L];
Cm = [[1 0];[0 1]];
C1 = [1 0];
C2 = [0 1];
D = [0];

sys1 = ss(A,B,C1,D);
sys2 = ss(A,B,C2,D);
v = eig(A);

[num1,den1] = ss2tf(A,B,C1,D);
[num2,den2] = ss2tf(A,B,C2,D);

H1 = tf(num1,den1);
H2 = tf(num2,den2);

%% Partie 2

Te1 = 0.1;
Te2 =1;

H1dzoh1 = c2d(H1, Te1, 'zoh');
H1dzoh2 = c2d(H1, Te2, 'zoh');
H2dzoh1 = c2d(H2, Te1, 'zoh');
H2dzoh2 = c2d(H2, Te2, 'zoh');
H1dtust1 = c2d(H1, Te1, 'tustin');
H1dtust2 = c2d(H1, Te2, 'tustin');
H2dtust1 = c2d(H2, Te1, 'tustin');
H2dtust2 = c2d(H2, Te2, 'tustin');

[num11, den11] = tfdata(H1dzoh1, 'v');
[num12, den12] = tfdata(H1dzoh2, 'v');

delta = 0.050;
precision1den = delta*abs(roots(den11)).*log(abs(roots(den11)));
% -0.0012 =>        4 CS denominateur car conjugué rajoute 1 chiffre
precision1num = delta*abs(roots(num11)).*log(abs(roots(num11)));
%  -8.1961e-04 =>   4 CS num
precision2den = delta*abs(roots(den12)).*log(abs(roots(den12)));
% -0.0097 =>        4 CS den car conjugué rajoute 1 chiffre
precision2num = delta*abs(roots(num12)).*log(abs(roots(num12)));
% -0.0071 =>        3 CS num

num11_d = [0 0.0012 0.0012];
den11_d = [1.0000  -1.9488   0.9512];
H1d1 = tf(num11_d, den11_d, Te1);

num12_d = [0 0.104 0.088];
den12_d = [1.0000  -1.4138   0.6065];
H1d2 = tf(num12_d, den12_d, Te2);

figure;
hold on;

subplot(2,1,1);
step(H1dzoh1, H1d1);
legend( "dicret BOZ", "tustin");
subplot(2,1,2);
step(H1dzoh2,H1d2);
legend( "dicret BOZ", "dtustin");



%% Partie 3
figure;
hold on;
subplot(2,1,1);
step(H1dzoh1, H1dtust1);
legend( "dicret BOZ", "tustin");
subplot(2,1,2);
step(H2dzoh1,H2dtust1);
legend( "dicret BOZ", "dtustin");
figure;
subplot(2,1,1);
step(H1dzoh2,H1dtust2);
legend("dicret BOZ","tustin");
subplot(2,1,2);
step(H2dzoh2,H2dtust2);
legend("dicret BOZ", "tustin");

%% Partie 4


figure;
hold on;
subplot(2,1,1);
bode(H1dzoh1, H1dtust1);
legend( "dicret BOZ", "tustin");
subplot(2,1,2);
bode(H2dzoh1,H2dtust1);
legend( "dicret BOZ", "dtustin");
figure;
subplot(2,1,1);
bode(H1dzoh2,H1dtust2);
legend("dicret BOZ","tustin");
subplot(2,1,2);
bode(H2dzoh2,H2dtust2);
legend("dicret BOZ", "tustin");




